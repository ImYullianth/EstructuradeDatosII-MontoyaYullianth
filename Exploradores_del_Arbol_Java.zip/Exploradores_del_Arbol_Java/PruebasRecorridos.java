import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Comprueba cada recorrido contra la secuencia esperada de la figura.
 * Ejecutar: java PruebasRecorridos
 */
public class PruebasRecorridos {

    private static int ok = 0, fallo = 0;

    public static void main(String[] args) {
        ArbolBSTProducto arbol = crearArbol();

        verificar("Preorden",
                codigos(arbol, "preorden"),
                List.of(50, 30, 20, 10, 25, 40, 70, 60, 80));
        verificar("Inorden",
                codigos(arbol, "inorden"),
                List.of(10, 20, 25, 30, 40, 50, 60, 70, 80));
        verificar("Postorden",
                codigos(arbol, "postorden"),
                List.of(10, 25, 20, 40, 30, 60, 80, 70, 50));
        verificar("Por niveles",
                codigos(arbol, "porNiveles"),
                List.of(50, 30, 70, 20, 40, 60, 80, 10, 25));

        // Inorden debe coincidir con las claves ordenadas de menor a mayor.
        List<Integer> in = codigos(arbol, "inorden");
        List<Integer> ordenada = new ArrayList<>(in);
        java.util.Collections.sort(ordenada);
        verificar("Inorden == claves ordenadas", in, ordenada);

        verificarBool("comprobarInorden() en árbol válido",
                arbol.comprobarInorden());

        ArbolBSTProducto vacio = new ArbolBSTProducto();
        verificar("Árbol vacío: inorden sin elementos",
                codigos(vacio, "inorden"), List.of());
        verificarBool("Árbol vacío: comprobarInorden() es true",
                vacio.comprobarInorden());

        System.out.println("\nResultado: " + ok + " pruebas OK, " + fallo + " fallidas.");
        if (fallo > 0) System.exit(1);
    }

    static ArbolBSTProducto crearArbol() {
        ArbolBSTProducto a = new ArbolBSTProducto();
        a.insertar(new Producto(50, "Laptop", 2500));
        a.insertar(new Producto(30, "Monitor", 800));
        a.insertar(new Producto(70, "Tablet", 1200));
        a.insertar(new Producto(20, "Teclado", 300));
        a.insertar(new Producto(40, "Impresora", 600));
        a.insertar(new Producto(60, "Cámara", 900));
        a.insertar(new Producto(80, "Celular", 1500));
        a.insertar(new Producto(10, "Mouse", 150));
        a.insertar(new Producto(25, "Audífonos", 250));
        return a;
    }

    /** Ejecuta el recorrido, captura lo que imprime y extrae los códigos. */
    static List<Integer> codigos(ArbolBSTProducto a, String recorrido) {
        PrintStream original = System.out;
        ByteArrayOutputStream buf = new ByteArrayOutputStream();
        System.setOut(new PrintStream(buf));
        try {
            switch (recorrido) {
                case "preorden":   a.preorden();   break;
                case "inorden":    a.inorden();    break;
                case "postorden":  a.postorden();  break;
                default:           a.porNiveles(); break;
            }
        } finally {
            System.setOut(original);
        }
        List<Integer> r = new ArrayList<>();
        Matcher m = Pattern.compile("(\\d+) - ").matcher(buf.toString());
        while (m.find()) r.add(Integer.parseInt(m.group(1)));
        return r;
    }

    static void verificar(String n, List<Integer> obtenido, List<Integer> esperado) {
        if (obtenido.equals(esperado)) { ok++; System.out.println("[OK]    " + n + ": " + obtenido); }
        else { fallo++; System.out.println("[FALLO] " + n + " obtenido=" + obtenido + " esperado=" + esperado); }
    }

    static void verificarBool(String n, boolean cond) {
        if (cond) { ok++; System.out.println("[OK]    " + n); }
        else { fallo++; System.out.println("[FALLO] " + n); }
    }
}
