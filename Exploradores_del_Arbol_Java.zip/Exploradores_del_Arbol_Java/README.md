# Actividad: Exploradores del árbol

Implementación en Java de los cuatro recorridos de un árbol binario de búsqueda
(BST) de productos: **Preorden, Inorden, Postorden y por niveles**, y comprobación
de que el **Inorden devuelve las claves ordenadas**.

## Contenido

| Archivo | Descripción |
|---|---|
| `Producto.java` | Código, nombre y precio |
| `NodoProducto.java` | Nodo con producto e hijos izquierdo/derecho |
| `ArbolBSTProducto.java` | Inserción recursiva, 4 recorridos y `comprobarInorden()` |
| `Main.java` | Construye el árbol de la figura y muestra los recorridos |
| `PruebasRecorridos.java` | Pruebas automáticas de cada recorrido |
| `Resultado_esperado.txt` | Salida de `Main` |
| `salida_pruebas.txt` | Salida de `PruebasRecorridos` |

## Compilar y ejecutar

```bash
javac *.java
java Main
java PruebasRecorridos
```

## Árbol utilizado

```text
                50 Laptop
              /           \
       30 Monitor          70 Tablet
       /        \          /        \
 20 Teclado  40 Impresora 60 Cámara  80 Celular
   /     \
10 Mouse  25 Audífonos
```

Se inserta en este orden: 50, 30, 70, 20, 40, 60, 80, 10, 25.

## Resultados (códigos)

| Recorrido | Orden de visita | Secuencia |
|---|---|---|
| Preorden | Raíz → Izquierda → Derecha | 50, 30, 20, 10, 25, 40, 70, 60, 80 |
| Inorden | Izquierda → Raíz → Derecha | 10, 20, 25, 30, 40, 50, 60, 70, 80 |
| Postorden | Izquierda → Derecha → Raíz | 10, 25, 20, 40, 30, 60, 80, 70, 50 |
| Por niveles (BFS) | Nivel por nivel, de izquierda a derecha | 50, 30, 70, 20, 40, 60, 80, 10, 25 |

## ¿Qué información produce cada recorrido?

- **Preorden:** visita primero la raíz y luego los subárboles. Como cada padre
  aparece antes que sus hijos, sirve para **copiar o serializar el árbol**:
  si se reinserta la secuencia en un BST vacío, se reconstruye la misma forma.
- **Inorden:** recorre en orden las claves. En un BST devuelve los códigos
  **ordenados de menor a mayor** (10, 20, 25, …, 80), por lo que sirve para
  listar el catálogo ordenado.
- **Postorden:** visita primero los hijos y al final la raíz. Sirve para
  **eliminar el árbol** (se borran los hijos antes que el padre) o calcular
  valores que dependen de los subárboles, como altura o total de precios.
- **Por niveles:** muestra los nodos nivel por nivel usando una cola.
  Permite **ver la estructura** del árbol y cómo se distribuyen los productos
  por nivel (nivel 0: 50; nivel 1: 30, 70; nivel 2: 20, 40, 60, 80; nivel 3: 10, 25).

## Comprobación: Inorden devuelve las claves ordenadas

Se cumple porque la regla del BST pone los códigos menores a la izquierda y los
mayores a la derecha: al visitar Izquierda → Raíz → Derecha, cada nodo aparece
después de todos los menores y antes de todos los mayores.

Se verifica de dos formas:

1. `comprobarInorden()` recorre el árbol y confirma que cada código es mayor
   o igual que el anterior; devuelve `true`.
2. `PruebasRecorridos` compara la secuencia inorden con las claves ordenadas
   por `Collections.sort`; son idénticas.

## Conclusión

- Inorden en un BST devuelve las claves ordenadas.
- Preorden, Postorden y por niveles recorren los mismos nodos en distinto
  orden, y cada uno es útil para una aplicación distinta (copiar, eliminar,
  visualizar la estructura).
