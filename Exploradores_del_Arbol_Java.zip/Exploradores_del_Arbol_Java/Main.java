public class Main {
    public static void main(String[] args) {
        ArbolBSTProducto arbol = new ArbolBSTProducto();

        arbol.insertar(new Producto(50, "Laptop", 2500));
        arbol.insertar(new Producto(30, "Monitor", 800));
        arbol.insertar(new Producto(70, "Tablet", 1200));
        arbol.insertar(new Producto(20, "Teclado", 300));
        arbol.insertar(new Producto(40, "Impresora", 600));
        arbol.insertar(new Producto(60, "Cámara", 900));
        arbol.insertar(new Producto(80, "Celular", 1500));
        arbol.insertar(new Producto(10, "Mouse", 150));
        arbol.insertar(new Producto(25, "Audífonos", 250));

        System.out.println("======================================");
        System.out.println("ACTIVIDAD: EXPLORADORES DEL ÁRBOL");
        System.out.println("======================================");

        arbol.preorden();
        arbol.inorden();
        arbol.postorden();
        arbol.porNiveles();

        System.out.println("\n¿Inorden devuelve las claves ordenadas?");
        System.out.println(arbol.comprobarInorden());
    }
}
