import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class Main {

    public static void main(String[] args) {

        List<Producto> productos = crearProductos();

        // =====================================================
        // ESCENARIO 1: INSERCIÓN ALEATORIA
        // =====================================================
        List<Producto> aleatorios = new ArrayList<>(productos);

        // Semilla fija: permite repetir exactamente la práctica.
        Collections.shuffle(aleatorios, new Random(42));

        ArbolBSTCatalogo bstAleatorio = new ArbolBSTCatalogo();

        for (Producto p : aleatorios) {
            bstAleatorio.insertar(p);
        }

        // =====================================================
        // ESCENARIO 2: INSERCIÓN ORDENADA
        // =====================================================
        List<Producto> ordenados = new ArrayList<>(productos);

        ordenados.sort(
                (a, b) -> Integer.compare(
                        a.getCodigo(),
                        b.getCodigo()
                )
        );

        ArbolBSTCatalogo bstOrdenado = new ArbolBSTCatalogo();

        for (Producto p : ordenados) {
            bstOrdenado.insertar(p);
        }

        // =====================================================
        // MOSTRAR ORDEN DE INSERCIÓN
        // =====================================================
        System.out.println("=== CATÁLOGO INTELIGENTE ===");

        System.out.println("\nOrden ALEATORIO:");
        imprimirCodigos(aleatorios);

        System.out.println("\nOrden ASCENDENTE:");
        imprimirCodigos(ordenados);

        // =====================================================
        // MOSTRAR LOS DOS ÁRBOLES
        // =====================================================
        System.out.println("\n=== BST ALEATORIO ===");
        bstAleatorio.imprimirArbol();
        System.out.println("Altura: " + bstAleatorio.altura());

        System.out.println("\n=== BST ORDENADO ===");
        bstOrdenado.imprimirArbol();
        System.out.println("Altura: " + bstOrdenado.altura());

        // =====================================================
        // BÚSQUEDAS
        // =====================================================
        int existente = 650;
        int inexistente = 700;

        System.out.println("\n=== BÚSQUEDAS EN BST ALEATORIO ===");
        mostrarBusqueda(bstAleatorio, existente);
        mostrarBusqueda(bstAleatorio, inexistente);

        System.out.println("\n=== BÚSQUEDAS EN BST ORDENADO ===");
        mostrarBusqueda(bstOrdenado, existente);
        mostrarBusqueda(bstOrdenado, inexistente);

        // =====================================================
        // COMPARACIÓN FINAL
        // =====================================================
        System.out.println("\n=== COMPARACIÓN FINAL ===");
        System.out.println(
                "Altura con datos aleatorios: "
                        + bstAleatorio.altura()
        );

        System.out.println(
                "Altura con datos ordenados: "
                        + bstOrdenado.altura()
        );

        System.out.println(
                "\nConclusión: el orden de inserción modifica "
                        + "la forma del BST. Cuando los datos llegan "
                        + "ordenados, el árbol puede degenerarse y "
                        + "aumentar considerablemente su altura."
        );

        // =====================================================
        // MOSTRAR CATÁLOGO ORDENADO POR CÓDIGO
        // =====================================================
        System.out.println("\n=== CATÁLOGO ORDENADO POR CÓDIGO ===");
        bstAleatorio.mostrarInorden();
    }

    private static void mostrarBusqueda(
            ArbolBSTCatalogo arbol,
            int codigo) {

        ResultadoBusqueda resultado =
                arbol.buscarConTraza(codigo);

        System.out.println("\nCódigo buscado: " + codigo);
        System.out.println(
                "Encontrado: " + resultado.encontrado()
        );
        System.out.println(
                "Comparaciones: " + resultado.getComparaciones()
        );
        System.out.println(
                "Camino: " + resultado.getCamino()
        );

        if (resultado.encontrado()) {
            System.out.println(
                    "Producto: " + resultado.getProducto()
            );
        }
    }

    private static void imprimirCodigos(
            List<Producto> productos) {

        for (Producto p : productos) {
            System.out.print(p.getCodigo() + " ");
        }
        System.out.println();
    }

    private static List<Producto> crearProductos() {

        List<Producto> lista = new ArrayList<>();

        lista.add(new Producto(50,  "Mouse",        "Periféricos",     45000));
        lista.add(new Producto(100, "Teclado",      "Periféricos",     85000));
        lista.add(new Producto(150, "Webcam",       "Periféricos",    120000));
        lista.add(new Producto(250, "SSD 500 GB",   "Almacenamiento", 220000));
        lista.add(new Producto(300, "Memoria USB",  "Almacenamiento",  38000));
        lista.add(new Producto(350, "Memoria RAM",  "Componentes",    180000));
        lista.add(new Producto(400, "Fuente poder", "Componentes",    260000));
        lista.add(new Producto(500, "Monitor",      "Pantallas",      780000));
        lista.add(new Producto(550, "Router",       "Redes",          190000));
        lista.add(new Producto(600, "Switch",       "Redes",          320000));
        lista.add(new Producto(650, "Access Point", "Redes",          410000));
        lista.add(new Producto(750, "Portátil",     "Computadores",  2800000));
        lista.add(new Producto(800, "Tablet",       "Computadores",  1250000));
        lista.add(new Producto(900, "Impresora",    "Oficina",        690000));
        lista.add(new Producto(950, "Escáner",      "Oficina",        560000));

        return lista;
    }
}
