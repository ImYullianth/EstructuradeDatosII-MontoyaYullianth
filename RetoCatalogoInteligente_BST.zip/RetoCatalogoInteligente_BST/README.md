# Reto: Catálogo inteligente (BST I: inserción y búsqueda)

Proyecto en Java para practicar Árboles Binarios de Búsqueda (BST).
Se construye un BST que almacena productos usando el **código** como clave,
con inserción y búsqueda **recursivas**, y se compara la altura del árbol
cuando los datos llegan **ordenados** frente a **aleatorios**.

## Contenido

| Archivo | Descripción |
|---|---|
| `Producto.java` | Entidad: código, nombre, categoría y precio |
| `NodoProducto.java` | Nodo del árbol (producto + hijo izquierdo/derecho) |
| `ResultadoBusqueda.java` | Resultado de búsqueda con comparaciones y camino |
| `ArbolBSTCatalogo.java` | BST: `insertar`, `buscar`, `buscarConTraza`, `altura`, inorden, impresión |
| `Main.java` | Escenarios aleatorio vs. ordenado y comparación |
| `PruebasBST.java` | Pruebas automáticas (sin JUnit) |
| `salida_ejecucion.txt` | Salida de `Main` |
| `salida_pruebas.txt` | Salida de `PruebasBST` |

## Compilar

```bash
javac Producto.java NodoProducto.java ResultadoBusqueda.java ArbolBSTCatalogo.java Main.java PruebasBST.java
```

## Ejecutar

```bash
java Main          # demostración y comparación
java PruebasBST    # pruebas
```

## Regla BST

```text
código menor -> izquierda
código mayor -> derecha
código igual -> se rechaza (IllegalArgumentException)
```

## Convención de altura

- árbol vacío = -1
- hoja = 0
- altura = número máximo de aristas desde la raíz hasta una hoja

## Datos de prueba

15 productos con códigos: 50, 100, 150, 250, 300, 350, 400, 500, 550, 600, 650, 750, 800, 900, 950.

- **Orden aleatorio** (`Collections.shuffle` con semilla 42, reproducible):
  `650 300 50 100 150 500 400 750 800 900 250 550 600 950 350`
- **Orden ascendente**:
  `50 100 150 250 300 350 400 500 550 600 650 750 800 900 950`

## Tabla comparativa BST ordenado vs. aleatorio

| Métrica | BST aleatorio | BST ordenado |
|---|---|---|
| Nodos (n) | 15 | 15 |
| Raíz | 650 | 50 |
| **Altura (aristas)** | **5** | **14** |
| Forma del árbol | Equilibrada aprox. | Degenerada (lista enlazada a la derecha) |
| Buscar 650 (existe): comparaciones | 1 | 11 |
| Buscar 650: camino | `650` | `50 -> 100 -> 150 -> 250 -> 300 -> 350 -> 400 -> 500 -> 550 -> 600 -> 650` |
| Buscar 700 (no existe): comparaciones | 2 | 12 |
| Buscar 700: camino | `650 -> 750 -> null` | `50 -> ... -> 650 -> 750 -> null` |
| Complejidad de búsqueda (caso típico) | O(log n) | O(n) |

## Conclusiones

1. El BST **no garantiza** equilibrio: su forma depende del orden de inserción.
2. Con datos ordenados cada nodo nuevo va siempre a la derecha, y el árbol
   se convierte en una lista: altura = n − 1 = 14 y la búsqueda pasa de
   O(log n) a O(n).
3. Con datos aleatorios la altura fue 5 (≈ log₂ 15 ≈ 3.9, más un pequeño
   desbalance), casi 3 veces menor que la del caso ordenado.
4. Como el costo de insertar y buscar es proporcional a la altura, el orden
   de llegada de los datos afecta directamente el rendimiento. Esto motiva
   los árboles autobalanceados (AVL, Rojo-Negro).
