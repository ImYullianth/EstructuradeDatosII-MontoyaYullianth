import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Pruebas del BST sin dependencias externas (no requiere JUnit).
 * Ejecutar: java PruebasBST
 */
public class PruebasBST {

    private static int pasadas = 0;
    private static int falladas = 0;

    public static void main(String[] args) {
        arbolVacio();
        insertarYBuscarExistente();
        buscarInexistente();
        codigoDuplicadoLanzaExcepcion();
        productoNullLanzaExcepcion();
        alturaConvencion();
        datosOrdenadosDegeneran();
        datosAleatoriosMenorAltura();
        trazaDeBusqueda();

        System.out.println("\nResultado: " + pasadas + " pruebas OK, "
                + falladas + " fallidas.");
        if (falladas > 0) System.exit(1);
    }

    // ---------- Pruebas ----------

    static void arbolVacio() {
        ArbolBSTCatalogo a = new ArbolBSTCatalogo();
        verificar("Árbol vacío: altura = -1", a.altura() == -1);
        verificar("Árbol vacío: buscar devuelve null", a.buscar(10) == null);
    }

    static void insertarYBuscarExistente() {
        ArbolBSTCatalogo a = new ArbolBSTCatalogo();
        a.insertar(p(50)); a.insertar(p(30)); a.insertar(p(70));
        Producto r = a.buscar(30);
        verificar("Buscar código existente lo encuentra",
                r != null && r.getCodigo() == 30);
        verificar("Buscar la raíz", a.buscar(50) != null);
    }

    static void buscarInexistente() {
        ArbolBSTCatalogo a = new ArbolBSTCatalogo();
        a.insertar(p(50)); a.insertar(p(30));
        verificar("Buscar código inexistente devuelve null",
                a.buscar(99) == null);
    }

    static void codigoDuplicadoLanzaExcepcion() {
        ArbolBSTCatalogo a = new ArbolBSTCatalogo();
        a.insertar(p(10));
        boolean lanzo = false;
        try { a.insertar(p(10)); }
        catch (IllegalArgumentException e) { lanzo = true; }
        verificar("Código duplicado lanza IllegalArgumentException", lanzo);
    }

    static void productoNullLanzaExcepcion() {
        ArbolBSTCatalogo a = new ArbolBSTCatalogo();
        boolean lanzo = false;
        try { a.insertar(null); }
        catch (IllegalArgumentException e) { lanzo = true; }
        verificar("Insertar null lanza IllegalArgumentException", lanzo);
    }

    static void alturaConvencion() {
        ArbolBSTCatalogo a = new ArbolBSTCatalogo();
        a.insertar(p(50));
        verificar("Un solo nodo (hoja): altura = 0", a.altura() == 0);
        a.insertar(p(30));
        verificar("Raíz + 1 hijo: altura = 1", a.altura() == 1);
        a.insertar(p(70));
        verificar("Raíz + 2 hijos: altura = 1", a.altura() == 1);
    }

    static void datosOrdenadosDegeneran() {
        ArbolBSTCatalogo a = new ArbolBSTCatalogo();
        int n = 15;
        for (int i = 1; i <= n; i++) a.insertar(p(i * 10));
        verificar("Datos ordenados (n=15): altura = n-1 = 14",
                a.altura() == n - 1);
    }

    static void datosAleatoriosMenorAltura() {
        int n = 15;
        List<Integer> codigos = new ArrayList<>();
        for (int i = 1; i <= n; i++) codigos.add(i * 10);

        ArbolBSTCatalogo ordenado = new ArbolBSTCatalogo();
        for (int c : codigos) ordenado.insertar(p(c));

        java.util.Collections.shuffle(codigos, new Random(42));
        ArbolBSTCatalogo aleatorio = new ArbolBSTCatalogo();
        for (int c : codigos) aleatorio.insertar(p(c));

        verificar("Altura aleatorio (" + aleatorio.altura()
                        + ") < altura ordenado (" + ordenado.altura() + ")",
                aleatorio.altura() < ordenado.altura());
    }

    static void trazaDeBusqueda() {
        ArbolBSTCatalogo a = new ArbolBSTCatalogo();
        for (int c : new int[]{50, 30, 70, 20, 40}) a.insertar(p(c));

        ResultadoBusqueda r = a.buscarConTraza(40);
        verificar("Traza: encontrado=true", r.encontrado());
        verificar("Traza: comparaciones = 3", r.getComparaciones() == 3);
        verificar("Traza: camino = 50 -> 30 -> 40",
                r.getCamino().equals("50 -> 30 -> 40"));

        ResultadoBusqueda n = a.buscarConTraza(45);
        verificar("Traza inexistente: encontrado=false", !n.encontrado());
        verificar("Traza inexistente: camino termina en null",
                n.getCamino().equals("50 -> 30 -> 40 -> null"));
    }

    // ---------- Utilidades ----------

    static Producto p(int codigo) {
        return new Producto(codigo, "Prod" + codigo, "Cat", codigo * 1000.0);
    }

    static void verificar(String nombre, boolean ok) {
        if (ok) { pasadas++; System.out.println("[OK]    " + nombre); }
        else    { falladas++; System.out.println("[FALLO] " + nombre); }
    }
}
